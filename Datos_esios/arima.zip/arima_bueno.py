# Best ARIMA model = (2, 1, 4)


from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.stattools import adfuller
import matplotlib.pyplot as plt
from tqdm import tqdm_notebook
import numpy as np
import pandas as pd
from itertools import product
import warnings
warnings.filterwarnings('ignore')



import warnings
import itertools
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pandas import ExcelWriter
import statsmodels.api as sm
import matplotlib
import pmdarima as pm

# %matplotlib inline

df = pd.read_csv('Demanda.csv',sep = ';', nrows = 35064)
df = pd.read_csv('dataset.csv',sep = ';', nrows = 17545)
df = pd.read_csv('Demanda.csv',sep = ';', nrows = 8761)


a = [str(date) for date in df['datetime']]
a = [date[:-6] for date in a]
date_time = pd.to_datetime(a)

df.loc[:,['datetime']] = date_time

ad_fuller_result = adfuller(df['precio_spot'])
print(f'ADF Statistic: {ad_fuller_result[0]}')
print(f'p-value: {ad_fuller_result[1]}')
# p-value is 2.019150432616161e-15 so we can assume that the trend is stationary

# Seasonal differencing
# df['precio_spot'] = df['precio_spot'].diff(365)
# data = data.drop([1, 2, 3, 4], axis=0).reset_index(drop=True)

plot_pacf(df['precio_spot'])
plot_acf(df['precio_spot'])

# Defining the exogenous variables and the target 
predictors = ['demanda_p48', 'eolica_p48']
target = 'precio_spot'

data_x = pd.get_dummies(df[predictors])
data_y = df.precio_spot

n = len(df)

# Training set
X_train = data_x[0:int(n*0.7)]
y_train = data_y[0:int(n*0.7)]

# # Validation set
# X_val = data_x[int(n*0.7):int(n*0.85)]
# y_val = data_y[int(n*0.7):int(n*0.85)]

# Test set
X_test = data_x[int(n*0.7):]
y_test = data_y[int(n*0.7):]

y_train.astype('float32')



from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX

s_model = SARIMAX(y_train, order = (2, 1, 4), seasonal_order = (0, 0, 1, 8760), trend = 'ct')
s_model = s_model.fit(disp=0)
prediction = s_model.predict(len(X_train), len(X_train) + len(X_test) - 1, typ ='Levels')

plt.plot(y_test, color = 'red', label = 'Actual demand')
plt.plot(prediction, color = 'blue', label = 'Predicted spot price')
plt.pause(1000)
plt.legend()
plt.xlabel('Hour')
plt.ylabel('Spot price')
plt.show()
